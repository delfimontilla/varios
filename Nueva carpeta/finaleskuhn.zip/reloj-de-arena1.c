#include<stdio.h>
#include<time.h>
#include<stdlib.h>

#define N 5

void crear_sub_matriz(int M[][N],int X[][N-2]);
void crear_matriz_aleatoria(int M[][N]);
void imprimir_matriz(int M[][N],int A);
void imprimir_sub_matriz(int M[][N],int x);
void imprimir_sub_diagonal_principal(int M[][N],int x);
void imprimir_sub_diagonal_secundaria(int M[][N],int x);
void imprimir_fila_der_a_izq(int M[][N],int x);
void imprimir_en_reloj_de_arena(int M[][N]);

int main()
{
	int M[N][N];
	int i,j;
	int X[N-2][N-2];

	crear_matriz_aleatoria(M);
	imprimir_matriz(M,N);
	printf("\n");
	imprimir_en_reloj_de_arena(M);
	printf("\n");
	return 0;
}

void crear_sub_matriz(int M[][N],int X[][N-2])
{
	int i,j;

	for(i=0;i<N-2;i++)
	{
		for(j=0;j<N-2;j++)
		{
			X[i][j]=M[i+1][j+1];
		}
	}
}

void crear_matriz_aleatoria(int M[][N])
{
	int x,i,j;

	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			x=rand()%10;
			M[i][j]=x;
		}
	}
}

void imprimir_matriz(int M[][N],int A)
{
	int i,j;

	for(i=0;i<A;i++)
	{
		for(j=0;j<A;j++)
			printf("%d ",M[i][j]);

		printf("\n");
	}
}

void imprimir_sub_matriz(int M[][N],int x)
{
	int i,j;

	for(i=x;i<N-x;i++)
	{
		for(j=x;j<N-x;j++)
			printf("%d ",M[i][j]);

		printf("\n");
	}
}

void imprimir_sub_diagonal_principal(int M[][N],int x)
{
	int i,j;

	for(i=x;i<N-x;i++)
		printf("%d ",M[i][i]);
}

void imprimir_sub_diagonal_secundaria(int M[][N],int x)
{
	int i=N-1-x,j=x;

	while(i>=x && j<N-x)
	{
		printf("%d ",M[i][j]);
		i--;
		j++;
	}
}

void imprimir_fila_der_a_izq(int M[][N],int x)
{
	int i;

	for(i=N-1;i>=0;i--)
		printf("%d ",M[x][i]);
}

void imprimir_en_reloj_de_arena(int M[][N])
{
	imprimir_fila_der_a_izq(M,N-1);
	imprimir_sub_diagonal_secundaria(M,1);
	imprimir_fila_der_a_izq(M,0);
	imprimir_sub_diagonal_principal(M,1);
}
