#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#define VOCALES_NUMBER 5
#define SEPARATORS_NUMBER 4
#define TWEET_MAX_LENGHT 140

void elim_vocales (char [], char **);
void es_vocal (char [], char [],char [], int, int *,char * string[]);

int main (void){
	char* tweet= "Hola, que Aces?";
	char * string;

	string= (char *) malloc (sizeof (char)* TWEET_MAX_LENGHT);
	elim_vocales (tweet, &string);
	puts (string);
	free(string);
	return 1;
}

void elim_vocales (char tweet [], char ** string){
	char vocales[VOCALES_NUMBER]= "aeiou";
	char vocales_mayus [VOCALES_NUMBER]= "AEIOU";
	char separators [SEPARATORS_NUMBER]=" .,!";
	int tweet_lenght, i=0, j ,k, m=0;

	tweet_lenght= strlen (tweet);
	/*if (tweet_lenght==1){
		(*string)[m]=tweet[0];
	}*/
	while (i<tweet_lenght){
		if (i==0){
			(*string)[m]=tweet[i];
			m++;
		}
		if ( i==tweet_lenght-1){
			(*string)[m]=tweet[i];
			(*string)[m+1]='\0';
		}
		else if(i!=0){	/*copia bordes*/
			for (j=0; j<VOCALES_NUMBER;j++){
				if (tweet [i]==vocales[j] || tweet[i]==vocales_mayus[j]){
					for (k=0;k<SEPARATORS_NUMBER;k++){
						if (tweet[i-1]==separators[k] || tweet[i+1]==separators[k]){
							(*string)[m]=tweet[i];
							m++;
						}
					}
				}
			}
			es_vocal (tweet, vocales, vocales_mayus, i, &m, string);
		}

		i++;
	}
}

void es_vocal (char tweet [], char vocales[], char vocales_mayus [], int i, int * m, char ** string){
	int j;

	for (j=0; j<=VOCALES_NUMBER; j++){
		if (tweet [i]==vocales[j] || tweet[i]==vocales_mayus[j]){
			return;
		}
	}
	(*string)[*m]=tweet[i];
	(*m)++;
}


