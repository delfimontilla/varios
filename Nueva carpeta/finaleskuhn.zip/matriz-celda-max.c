#include<stdio.h>

#define N 5
#define X 25

typedef struct{
	int fila;
	int columna;
	int suma;
}posicion;

posicion maxima_suma(int M[][5]);
int sumar_vecinos(int M[][5],int i,int j);
void ordenar_vector_de_posiciones(posicion pos[]);
void intercambiar_posiciones(posicion *pos1,posicion *pos2);

int main(void)
{
	int M[N][N]={1,5,8,13,8,10,0,4,3,9,1,600,23,4,0,5,9,8,38,100,7,0,6,400,10};
	int i,j;

	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
			printf("%d ",M[i][j]);

		printf("\n");
	}

	printf("la posicion maxima es (%d,%d)\n",(maxima_suma(M).fila)+1,(maxima_suma(M).columna)+1);

	return 0;
}

posicion maxima_suma(int M[][5])
{
	posicion pos[25];
	int i,j,k=0;

	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			pos[k].fila=i;
			pos[k].columna=j;
			pos[k].suma=sumar_vecinos(M,i,j);
			k++;
		}
	}

	ordenar_vector_de_posiciones(pos);

	return pos[X-1];
}

int sumar_vecinos(int M[][5],int i,int j)
{
	int suma=0;

	if(i-1>=0) suma=M[i-1][j];
	if(i+1<=N-1) suma=suma+M[i+1][j];
	if(j-1>=0) suma=suma+M[i][j-1];
	if(j+1<=N-1) suma=suma+M[i][j+1];
	if(i-1>=0 && j-1>=0) suma=suma+M[i-1][j-1];
	if(i-1>=0 && j+1<=N-1) suma=suma+M[i-1][j+1];
	if(i+1<=N-1 && j-1>=0) suma=suma+M[i+1][j-1];
	if(i+1<=N-1 && j+1<=N+1) suma=suma+M[i+1][j+1];

	return suma;
}	

void ordenar_vector_de_posiciones(posicion pos[])
{
	int i,j;

	for(j=0;j<=X-2;j++)
	{
		for(i=0;i<X-j-1;i++)
		{
			if(pos[i].suma>pos[i+1].suma)
			{
				intercambiar_posiciones(&(pos[i]),&(pos[i+1]));
			}
		}
	}
}

void intercambiar_posiciones(posicion *pos1,posicion *pos2)
{
	int auxfila,auxcolumna,auxsuma;

	auxfila=pos1->fila;
	auxcolumna=pos1->columna;
	auxsuma=pos1->suma;

	pos1->fila=pos2->fila;
	pos1->columna=pos2->columna;
	pos1->suma=pos2->suma;

	pos2->fila=auxfila;
	pos2->columna=auxcolumna;
	pos2->suma=auxsuma;
}
