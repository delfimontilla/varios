#include<stdio.h>
#include<time.h>
#include<stdlib.h>

#define N 5

void crear_matriz_aleatoria(int M[][N]);
void imprimir_matriz(int M[][N],int x);
void imprimir_en_reloj_de_arena(int M[][N]);
void imprimir_fila_izq_der(int M[][N],int x);
void imprimir_sub_diagonal_secundaria(int M[][N],int x);
void imprimir_sub_diagonal_principal(int M[][N],int x);

int main()
{
	int M[N][N];

	crear_matriz_aleatoria(M);
	imprimir_matriz(M,N);
	printf("\n");
	imprimir_en_reloj_de_arena(M);
	printf("\n");

	return 0;
}

void crear_matriz_aleatoria(int M[][N])
{
	int i,j,x;

	for(i=0;i<N;i++)
	{
		for(j=0;j<N;j++)
		{
			x=rand()%10;
			M[i][j]=x;
		}
	}
}

void imprimir_matriz(int M[][N],int x)
{
	int i,j;

	for(i=0;i<x;i++)
	{
		for(j=0;j<x;j++)
			printf("%d ",M[i][j]);

		printf("\n");
	}
}

void imprimir_en_reloj_de_arena(int M[][N])
{
	imprimir_fila_izq_der(M,0);
	imprimir_sub_diagonal_secundaria(M,1);
	imprimir_fila_izq_der(M,N-1);
	imprimir_sub_diagonal_principal(M,1);
}

void imprimir_fila_izq_der(int M[][N],int x)	
{
	int i;

	for(i=0;i<N;i++)
		printf("%d ",M[x][i]);
}

void imprimir_sub_diagonal_secundaria(int M[][N],int x)
{
	int i=x,j=N-1-x;

	while(j>=x && i<=N-1-x)
	{
		printf("%d ",M[i][j]);
		i++;
		j--;
	}
}

void imprimir_sub_diagonal_principal(int M[][N],int x)
{
	int i=N-1-x,j=N-1-x;

	while(i>=x && j>=x)
	{
		printf("%d ",M[i][j]);
		i--;
		j--;
	}
}
