/*
  CONSIGNA:
  Escribir una función que ingrese números reales por teclado, que representan
  temperaturas diarias durante un lapso de tiempo. La función debe devolver 
  el promedio de las temperaturas comprendidas entre la mayor temperatura 
  leída y la menor temperatura leída. 
  Ejemplo:
  3.2 4 8.1 -1.2 2.5 -3.2 1.2 3.4 10 ----> devuelve (1.2+3.4)/2
  3.2 4 8.1 -1.2 2.5 -3.2 1.2  ----> devuelve (-1.2+2.5)/2

  
  En este archivo se hace lo pedido (se pueden ingresar hasta MAX_TEMP valores)
  sin usar vectores o estructuras auxiliares.

*/

#include <stdio.h>

#define MAX_TEMP 20


int main(void){
  float max=0.0, min=0.0, suma_total=0.0,suma_hasta_max=0.0,suma_hasta_min=0.0,nueva_temp=0.0;
  int i_max=0,i_min=0,i=0;

  while(i<MAX_TEMP){
    printf("Nueva temperatura: ");
    scanf("%f",&nueva_temp);
    i++;
    suma_total=suma_total+nueva_temp;
    switch(i){
    case 1:
      max=nueva_temp;
      printf("Promedio: 0\n");
      break;
    case 2:
      if(max<nueva_temp){
	min=max;
	max=nueva_temp;
	i_max=2;
	i_min=1;
	suma_hasta_max=min+max;
	suma_hasta_min=min;
      }
      else{
	min=nueva_temp;
	i_max=1;
	i_min=2;
	suma_hasta_min=max+min;
	suma_hasta_max=max;
      }	  
      printf("Promedio: 0\n");
      break;
    default:
      if(nueva_temp>max){
	max=nueva_temp;
	suma_hasta_max=suma_total;
	i_max=i;
      }
      if(nueva_temp<min){
	min=nueva_temp;
	suma_hasta_min=suma_total;
	i_min=i;
      }
      if(i_max>i_min && i_max!=i_min+1)
	printf("Promedio: %f\n",(suma_hasta_max-suma_hasta_min-max)/(i_max-i_min-1));
      if(i_max<i_min && i_min!=i_max+1)
	printf("Promedio: %f\n",(suma_hasta_min-suma_hasta_max-min)/(i_min-i_max-1));	
      if(i_max==i_min+1 || i_min==i_max+1)
	printf("Promedio: 0\n");
      break;
    }
  }
  return 1;
}
