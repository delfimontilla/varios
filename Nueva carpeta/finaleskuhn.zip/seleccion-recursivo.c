#include<stdio.h>
#include<stdlib.h>

#define N 6
void espacio();
void imprimir_vector(int V[]);
void ordenar_por_seleccion_recursiva(int V[],int Z);
void intercambiar(int *x,int *y);
void encontrar_menor(int V[],int **aux,int X);

int main()
{
	int V[N]={9,6,2,4,8,5};

	imprimir_vector(V);
	ordenar_por_seleccion_recursiva(V,N);
	espacio();
	imprimir_vector(V);
	espacio();

	return 0;
}

void espacio()
{
	printf("\n");
}

void imprimir_vector(int V[])
{
	int i;
	
	for(i=0;i<N;i++)
		printf("%d ",V[i]);
}

void ordenar_por_seleccion_recursiva(int V[],int Z)
{
	int *aux=V;
	if(Z>1)
	{
		encontrar_menor(V,&aux,Z);
		intercambiar(V,aux);
	        ordenar_por_seleccion_recursiva(V+1,Z-1);
	}
}

void intercambiar(int *x,int *y)
{
	int temp;

	temp=*x;
	*x=*y;
	*y=temp;
}

void encontrar_menor(int V[],int **aux,int X)
{
	if(X>1)
	{
		if(V[1]<**aux)
		{
			*aux=V+1;
			encontrar_menor(V+1,aux,X-1);
		}
		else encontrar_menor(V+1,aux,X-1);
	}
}	
