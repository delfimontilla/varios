#include <stdio.h>
#include <stdlib.h>

#define N 4

typedef struct nodo{
	int campo;
	struct nodo* sig;
}tnodo;

tnodo* recorrer_hasta(tnodo* lista, int pos);
void agregar_nodo_al_final(tnodo** lista, tnodo* nodo);
void elim_cols(tnodo *VE[], tnodo *VCOL[]);
void inicializar_cols(tnodo** VCOL);
void imprimir_lista(tnodo * lista);
void insertar_al_final(tnodo **l,int val);
void crear_vector_de_listas(tnodo *VE[]);
tnodo *crear_lista(void);
void imprimir_vector_de_listas(tnodo* lista[],int );

int main(){
	tnodo* VE[N],*VCOL[N];
	int i;

	for(i=0;i<N+1;i++)
		inicializar_cols(&(VCOL[i]));

	crear_vector_de_listas(VE);

	imprimir_vector_de_listas(VE,N);

	elim_cols(VE,VCOL);
	printf("Las columnas impares\n");
	imprimir_vector_de_listas(VCOL,N);

	return EXIT_SUCCESS;

}


void imprimir_lista(tnodo * lista){
	tnodo* aux;

	aux=lista;
	while(aux != NULL){
		printf("%d\t",aux->campo);
		aux=aux->sig;
	}
	printf("\n");


}

void crear_vector_de_listas(tnodo *VE[])
{
	int i;

	for(i=0;i<N;i++)
		VE[i]=crear_lista();
}

tnodo *crear_lista(void)
{
	tnodo *l=NULL;
	int i,val,cant=(rand()%7)+1;

	for(i=0;i<cant;i++)
	{
		val=rand()%10;
		insertar_al_final(&l,val);
	}

	return l;
}
/*Crea un nodo a partir de un valor y lo agrega a la lista*/
void insertar_al_final(tnodo **l,int val)
{
	tnodo *aux;

	if((*l)==NULL)
	{
		(*l)=(tnodo *)malloc(sizeof(tnodo));
		(*l)->campo=val;
		(*l)->sig=NULL;
	}
	else
	{
		aux=*l;
		while(aux->sig != NULL) 
			aux=aux->sig;

		aux->sig=(tnodo *)malloc(sizeof(tnodo));
		aux->sig->campo=val;
		aux->sig->sig=NULL;
	}
}

/*Inicializa un vector de listas en NULL*/
void inicializar_cols(tnodo** VCOL){

	*VCOL=NULL;


}

/*Toma las columas formadas por los nodos impares de un vector de listas y las guarda como listas en otro vector*/
void elim_cols(tnodo *VE[N], tnodo *VCOL[N]){
	tnodo * aux;
	int i,j;

	for(i=0;i<N;i++){
		for(j=0;j<N;j++){
			aux = recorrer_hasta(VE[j],i);
			if(aux != NULL && aux->sig != NULL){
				agregar_nodo_al_final(&(VCOL[i]),aux);
			}
		}
	}
}


/*Anexa un nodo al final de la lista y apunta el sig a NULL.*/
void agregar_nodo_al_final(tnodo** lista, tnodo* nodo){
	tnodo* aux=NULL;

	if(*lista == NULL){
		*lista = nodo->sig;
		nodo->sig = (*lista)->sig;
		(*lista)->sig = NULL;
	}
	else{
		aux = *lista;
		while(aux->sig!=NULL){
			aux=aux->sig;
		}
		aux->sig = nodo->sig;
		nodo->sig = aux->sig->sig;
		aux->sig->sig = NULL;
	}
}

/*Recibe una lista y un entero. Recorre la lista hasta la posicion "pos"*/
tnodo* recorrer_hasta(tnodo* lista, int pos){
	int i;
	tnodo* aux=NULL;

	aux = lista;
	for(i=0;i<pos;i++){
		aux=aux->sig;
		if(aux == NULL)
			return NULL;
	}

	return aux;
}

/*Recibe un vector de listas y las imprime de forma iterativa*/
void imprimir_vector_de_listas(tnodo *VE[],int A)
{
	int i;

	for(i=0;i<A;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}
}