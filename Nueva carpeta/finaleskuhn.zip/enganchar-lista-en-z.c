#include<stdio.h>
#include<stdlib.h>

#define N 6

typedef struct NODO{
	int val;
	struct NODO *sig;
}T_NODO;

void espacio();
void crear_vector_de_listas(T_NODO *VE[]);
T_NODO *crear_lista();
void insertar_al_final(T_NODO **l,int val);
void imprimir_lista(T_NODO *l);
void imprimir_vector_de_listas(T_NODO *VE[],int x);
T_NODO *enganchar_en_z(T_NODO *VE[]);
T_NODO *recorrer_hasta(T_NODO *l,int x);
void enganchar_de_derecha_a_izquierda(T_NODO **l);
void enganchar_diagonal_secundaria(T_NODO *VE[]);

int main()
{
	T_NODO *VE[N],*Z=NULL;

	crear_vector_de_listas(VE);
	imprimir_vector_de_listas(VE,N);
	Z=enganchar_en_z(VE);
	espacio();
	imprimir_lista(Z);
	espacio();

	return 0;
}

void espacio(){printf("\n");}

void crear_vector_de_listas(T_NODO *VE[])
{
	int i;
	for(i=0;i<N;i++) VE[i]=crear_lista();
}

T_NODO *crear_lista()
{
	T_NODO *l=NULL;
	int i,val;

	for(i=0;i<N;i++)
	{
		val=rand()%10;
		insertar_al_final(&l,val);
	}

	return l;
}

void insertar_al_final(T_NODO **l,int val)
{
	if((*l)==NULL)
	{
		(*l)=(T_NODO *)malloc(sizeof(T_NODO));
		(*l)->val=val;
		(*l)->sig=NULL;
	}
	else
	{
		T_NODO *aux=*l;
		while(aux->sig) aux=aux->sig;
		aux->sig=(T_NODO *)malloc(sizeof(T_NODO));
		aux->sig->val=val;
		aux->sig->sig=NULL;
	}
}

void imprimir_vector_de_listas(T_NODO *VE[],int x)
{
	int i;
	for(i=0;i<x;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}
}

void imprimir_lista(T_NODO *l)
{
	T_NODO *aux=l;
	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->sig;
	}
}

T_NODO *enganchar_en_z(T_NODO *VE[])
{
	T_NODO *p=NULL;

	p=recorrer_hasta(VE[N-1],N-1);
	enganchar_de_derecha_a_izquierda(VE+N-1);
	enganchar_diagonal_secundaria(VE);
	enganchar_de_derecha_a_izquierda(VE);

	return p;
}

T_NODO *recorrer_hasta(T_NODO *l,int x)
{
	T_NODO *p=l;
	int i;

	for(i=0;i<x;i++)
		p=p->sig;

	return p;
}

void enganchar_de_derecha_a_izquierda(T_NODO **l)
{
	int i;

	for(i=N-1;i>0;i--)
		recorrer_hasta(*l,i)->sig=recorrer_hasta(*l,i-1);

	(*l)->sig=NULL;
}

void enganchar_diagonal_secundaria(T_NODO *VE[])
{
	int i=N-1,j=0;

	while(i>0 && j<N)
	{
		recorrer_hasta(VE[i],j)->sig=recorrer_hasta(VE[i-1],j+1);
		j++;
		i--;
	}
}
