#include<stdio.h>
#include<stdlib.h>

#define N 7 /*longitud del vector de listas*/
#define W 7 /*cantidad de nodos de cada lista*/

typedef struct NODO{
	int val;
	struct NODO *sig;
}T_NODO;

void espacio();
void crear_vector_de_listas(T_NODO *VE[]);
T_NODO *crear_lista(void);
void insertar_al_final(T_NODO **l,int val);
void imprimir_vector_de_listas(T_NODO *VE[]);
void imprimir_lista(T_NODO *l);
T_NODO *diagonal_principal(T_NODO *VE[]);
T_NODO *diagonal_secundaria(T_NODO *VE[]);
T_NODO *recorrer_hasta(T_NODO *VE,int i);
int par(int x);

int main(void)
{
	T_NODO *VE[N],*DP=NULL,*DS=NULL;

	crear_vector_de_listas(VE);
	espacio();
	imprimir_vector_de_listas(VE);
	DP=diagonal_principal(VE);
	DS=diagonal_secundaria(VE);
	espacio();
	imprimir_lista(DP);
	espacio();
	imprimir_lista(DS);
	espacio();

	return 0;
}

void espacio() {printf("\n");}

void crear_vector_de_listas(T_NODO *VE[])
{
	int i;
	
	for(i=0;i<N;i++)
		VE[i]=crear_lista();
}

T_NODO *crear_lista(void)	/*crea una lista aleatoria*/
{
	T_NODO *l=NULL;
	int i,val;

	for(i=0;i<W;i++)
	{
		val=rand()%10;
		insertar_al_final(&l,val);
	}

	return l;
}

void insertar_al_final(T_NODO **l,int val)
{
	if((*l)==NULL)
	{
		(*l)=(T_NODO *)malloc(sizeof(T_NODO));
		(*l)->val=val;
		(*l)->sig=NULL;
	}
	else
	{
		T_NODO *aux=*l;
		while(aux->sig) aux=aux->sig;
		aux->sig=(T_NODO *)malloc(sizeof(T_NODO));
		aux->sig->val=val;
		aux->sig->sig=NULL;
	}
}

void imprimir_vector_de_listas(T_NODO *VE[])
{
	int i;

	for(i=0;i<N;i++)
	{	
		imprimir_lista(VE[i]);
		printf("\n");
	}	
}

void imprimir_lista(T_NODO *l)
{
	T_NODO *aux=l;

	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->sig;
	}
}

T_NODO *diagonal_principal(T_NODO *VE[])
{
	int i;
	T_NODO *diag=NULL,*aux=NULL;

	for(i=0;i<N-1;i++)
	{
		if(i==0)
		{
			aux=VE[0];
			VE[0]=aux->sig;
			aux->sig=VE[1]->sig;
			diag=aux;
		}
		else
		{
			aux=recorrer_hasta(VE[i],i);
			recorrer_hasta(VE[i],i-1)->sig=aux->sig;
			aux->sig=recorrer_hasta(VE[i+1],i+1);
		}
	}
	
	return diag;
}

T_NODO *recorrer_hasta(T_NODO *VE,int i)
{
	int j;
	T_NODO *p=VE;

	for(j=0;j<i;j++)
		p=p->sig;

	return p;
}

T_NODO *diagonal_secundaria(T_NODO *VE[])
{
	int i=N-1,j=0;
	T_NODO *diag=VE[N-1];
	if(par(N))
	{
		while(i>0 && j<N-1)
		{
			if(i==(N/2))
			{
				recorrer_hasta(VE[i],j)->sig=recorrer_hasta(VE[i-1],j);
				i--;
			
			}
			else			
			{
				recorrer_hasta(VE[i],j)->sig=recorrer_hasta(VE[i-1],j+1);
				i--;
				j++;
			}
		}
	}
	else
	{
		while(i>0 && j<N-1)
		{
			if(i==(N/2)+1)
			{
				recorrer_hasta(VE[i],j)->sig=recorrer_hasta(VE[i-2],j+1);
				i=i-2;
				j++;
			}
			else
			{
				recorrer_hasta(VE[i],j)->sig=recorrer_hasta(VE[i-1],j+1);
				i--;
				j++;
			}
		}
	}
	return diag;
}

int par(int x)
{
	if(!(x%2)) return 1;
	else return 0;
}
