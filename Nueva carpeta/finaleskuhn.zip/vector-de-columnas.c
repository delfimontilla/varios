#include<stdio.h>
#include<stdlib.h>
#include<time.h>

#define N 5

typedef struct NODO{
	int val;
	struct NODO *sig;
}T_NODO;

T_NODO *crear_lista(void);
void insertar_al_final(T_NODO **l,int val);
void imprimir_lista(T_NODO *l);
int cantidad_de_elementos_de_lista(T_NODO *l);
void crear_vector_de_listas(T_NODO *VE[]);
void imprimir_vector_de_listas(T_NODO *VE[]);
void crear_vector_de_columnas(T_NODO *VE[],T_NODO *VCOL[]);
T_NODO *recorrer_hasta(T_NODO *l,int z);

int main(void)
{
	T_NODO *VE[N],*VCOL[N];
	int i;

	crear_vector_de_listas(VE);	
	printf("\n");
	/*primero imprimo la lista tal cual la cree*/
	imprimir_vector_de_listas(VE);
	printf("\n");
	crear_vector_de_columnas(VE,VCOL);
	imprimir_vector_de_listas(VCOL);	
	printf("\n");

	return 0;
}

T_NODO *crear_lista(void)
{
	T_NODO *l=NULL;
	int i,val,cant=5;

	/*srand(time(NULL));*/

	/*printf("Ingrese cantidad de elementos: \n");
	scanf("%d",&cant);*/

	printf("Ingrese numeros: \n");
	for(i=0;i<cant;i++)
	{
		val=rand()%10;
		insertar_al_final(&l,val);
	}

	return l;
}

void insertar_al_final(T_NODO **l,int val)
{
	if((*l)==NULL)
	{
		(*l)=(T_NODO *)malloc(sizeof(T_NODO));
		(*l)->val=val;
		(*l)->sig=NULL;
	}
	else
	{
		T_NODO *aux=*l;
		while(aux->sig) aux=aux->sig;

		aux->sig=(T_NODO *)malloc(sizeof(T_NODO));
		aux->sig->val=val;
		aux->sig->sig=NULL;
	}
}

void imprimir_lista(T_NODO *l)
{
	T_NODO *aux=l;

	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->sig;
	}
}

void imprimir_vector_de_listas(T_NODO *VE[])
{
	int i;

	for(i=0;i<N;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}
}

void crear_vector_de_listas(T_NODO *VE[])
{
	int i;

	for(i=0;i<N;i++)
		VE[i]=crear_lista();
}

int cantidad_de_elementos_de_lista(T_NODO *l)
{
	int i,cant=0;
	T_NODO *aux=l;

	while(aux)
	{
		aux=aux->sig;
		cant++;
	}

	return cant;
}

T_NODO *recorrer_hasta(T_NODO *l,int z)
{
	int i;
	T_NODO *p=l;

	for(i=0;i<z;i++)
		p=p->sig;

	return p;
}

void crear_vector_de_columnas(T_NODO *VE[],T_NODO *VCOL[])
{
	int i,j;
	T_NODO *p=NULL;

	for(j=0;j<N;j++)
	{
		VCOL[j]=VE[0];		
	
		for(i=0;i<N-1;i++)
		{
			p=VE[i];
			VE[i]=VE[i]->sig;
			p->sig=VE[i+1];
		}

		i=N-1;
		
		p=VE[i];
		VE[i]=VE[i]->sig;
		p->sig=NULL;

	}
}
