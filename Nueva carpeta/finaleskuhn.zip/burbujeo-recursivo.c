#include<stdio.h>

#define N 12
void imprimir_vector(int V[]);
void espacio();
void ordenar_burbujeo_recursivo(int V[],int Z);
void cambiar_posiciones(int V[],int Z,int X);
void intercambiar(int *x,int *y);

int main()
{
	int V[N]={9,6,2,4,8,5,1,0,32,1,8,6};

	imprimir_vector(V);
	espacio();
	ordenar_burbujeo_recursivo(V,0);
	imprimir_vector(V);
	espacio();

	return 0;
}

void imprimir_vector(int V[])
{
	int i;
	for(i=0;i<N;i++) printf("%d ",V[i]);
}

void espacio()
{
	printf("\n");
}

void ordenar_burbujeo_recursivo(int V[],int Z)
{
	if(Z<N-1)
	{
		cambiar_posiciones(V,Z,0);
		ordenar_burbujeo_recursivo(V,Z+1);
	}
}

void cambiar_posiciones(int V[],int Z,int X)
{
	if(X<N-Z-1)
	{
		if(V[0]>V[1])
		{
			intercambiar(V,V+1);
			cambiar_posiciones(V+1,Z,X+1);
		}
		else cambiar_posiciones(V+1,Z,X+1);
	}
}

void intercambiar(int *x,int *y)
{
	int temp;

	temp=*x;
	*x=*y;
	*y=temp;
}
