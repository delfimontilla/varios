#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define GERENTES_SIZE 3
#define JEFES_SIZE GERENTES_SIZE*2
#define EMPLEADOS_SIZE JEFES_SIZE*2

typedef struct persona{

  char nombre[20];
  char antecesor[20];
  struct persona * sig;
  struct persona *prox;
} pers;

void reverse(char s[]);
void itoa(int n, char s[]);
int crear_lista_familia(pers **ger_dir, pers **jefe_dir, pers **empl_dir);

void enganchar(pers *GERENTES, pers **JEFES, pers **EMPLEADOS);
pers *buscar_jefe_de(char *s,pers **lista);

void imprimir_lista(pers *head);
void destruir_lista(pers **lista_dir);

void enganchar_EMPLEADOS(pers **familia);
int es_gerente(pers *nodo);
int es_empleado(pers *nodo, char nombre_gerente[]);
void imprimir_prox(pers *head);

/* int shuffle(void **array, int n); */
/* pers *crear_lista_GERENTES(char **vec_GERENTES); */
/* pers *crear_lista_JEFES(char **vec_JEFES, char **vec_GERENTES); */

int main (void){
  pers *GERENTES=NULL, *JEFES=NULL, *EMPLEADOS=NULL;
  srand(time(NULL));

  /*Se crean las listas de GERENTES, JEFES y EMPLEADOS.*/
  crear_lista_familia(&GERENTES, &JEFES, &EMPLEADOS);
  imprimir_lista(GERENTES);
  imprimir_lista(JEFES);
  imprimir_lista(EMPLEADOS);

  enganchar(&GERENTES,empleados);
  putchar('\n');
  putchar('\n');
  imprimir_prox(GERENTES);
  
  destruir_lista(&GERENTES);
    
  return 1;
}



/************* FUNCIONES gerRA LA PRIMERA gerRTE ***************/

void enganchar(pers *GERENTES, pers **jefe_dir, pers **empl_dir){
  pers *aux0=NULL, *aux1=GERENTES, *aux2=NULL, *aux3=NULL;

  while(aux1!=NULL){
    aux2=aux1->sig;
    aux3=buscar_jefe_de(aux1->nombre,jefe_dir);
    while(aux3!=NULL){
      aux3->sig=aux1->sig;
      aux1->sig=aux3;
      aux3=buscar_jefe_de(aux1->nombre,jefe_dir);
    }
    while(aux1->sig!=aux2)
      aux1=aux1->sig;
    while(strcmp(aux1->antecesor,"")){
      aux3=buscar_jefe_de(aux1->nombre,empl_dir);
      while(aux3!=NULL){
	aux3->sig=aux1->sig;
	aux1->sig=aux3;
	aux3=buscar_jefe_de(aux1->nombre,empl_dir);
      }
      aux0=GERENTES;
      while(aux0->sig!=aux1)
	aux0=aux0->sig;
      aux1=aux0;
    }
    aux1=aux2;
  }  
}


pers *buscar_jefe_de(char *s,pers **lista){
  pers *aux1=*lista, *aux2=*lista;

  if(aux1==NULL)
    return NULL;
  if(!strcmp((*lista)->antecesor,s)){
    *lista=aux2->sig;
    aux2->sig=NULL;
    return aux2;
  }
  while(aux2!=NULL){
    if(strcmp(aux2->antecesor,s))
      aux2=aux2->sig;
    else
      break;
  }
  if(aux2==NULL)
    return NULL;
  while(aux1->sig!=aux2)
    aux1=aux1->sig;
  aux1->sig=aux2->sig;
  aux2->sig=NULL;
  return aux2;
}
/************* FUNCIONES gerRA LA SEGUNDA gerRTE ***************/

void enganchar_EMPLEADOS(pers **familia){
  pers *aux1=*familia, *aux2=NULL;
  char gerente[20];

  strcpy(gerente,aux1->nombre);
  aux2=aux1->sig;
  
  while(aux2!=NULL){
    if(es_gerente(aux2)){
      aux1=aux2;
      strcpy(gerente,aux1->nombre);
      aux2=aux2->sig;
    }
    else{
      if(es_empleado(aux2,gerente)){
	aux1->prox=aux2;
	aux1=aux2;
	aux2=aux2->sig;
      }
      else
	aux2=aux2->sig;      
    }
  } 
}

int es_gerente(pers *nodo){
  if(nodo->antecesor==NULL)
    return 1;
  return 0;
}

int es_empleado(pers *nodo, char nombre_gerente[]){
  if(!strcmp(nodo->antecesor,nombre_gerente))
    return 0;
  return 1;
}
void imprimir_lista(pers *head){
  pers *aux=head;

  while(aux!=NULL){
    printf("Nombre: %s \t\t Antecesor: %s\n",aux->nombre,aux->antecesor);
    aux=aux->sig;
  }    
}


void destruir_lista(pers **lista_dir){
  pers *aux=*lista_dir;

  while(*lista_dir!=NULL){
    *lista_dir=(*lista_dir)->sig;
    free(aux);
    aux=*lista_dir;
  }
    
}

void reverse(char s[]){
  int c=0,i=0,j=0;
  for(i=0,j=strlen(s)-1;i<j;i++,j--){
    c=s[i];
    s[i]=s[j];
    s[j]=c;
  }
}


void itoa(int n, char s[]){
  int i=0;
  do{
    s[i++]=n%10+'0';
  }while((n/=10)>0);
  s[i]='\0';
  reverse(s);
}


int crear_lista_familia(pers **ger_dir, pers **jefe_dir, pers **empl_dir){
  char ger[10]="gerente", jefe[10]="jefe", empl[10]="empleado", num[10]="99";
  pers *curr=NULL,*aux=NULL;
  int i=0, j=0, n=0;
  *ger_dir=NULL;
  for(i=GERENTES_SIZE;i>0;i--){
    if((curr=(pers *)malloc(sizeof(pers)))==NULL)
      return -1;
    itoa(i,num);
    strcpy(ger,"gerente");
    strcpy(curr->nombre,strcat(ger,num));
    strcpy(curr->antecesor,"");
    curr->sig=*ger_dir;
    *ger_dir=curr;
  }
  for(i=JEFES_SIZE;i>0;i--){
    if((curr=(pers *)malloc(sizeof(pers)))==NULL)
      return -1;
    itoa(i,num);
    strcpy(jefe,"jefe");
    strcpy(curr->nombre,strcat(jefe,num));
    n=rand()%GERENTES_SIZE;
    aux=*ger_dir;
    for(j=0;j<n;j++)
      aux=aux->sig;    
    strcpy(curr->antecesor,aux->nombre);
    curr->sig=*jefe_dir;
    *jefe_dir=curr;
  }
  for(i=EMPLEADOS_SIZE;i>0;i--){
    if((curr=(pers *)malloc(sizeof(pers)))==NULL)
      return -1;
    itoa(i,num);
    strcpy(empl,"empleado");
    strcpy(curr->nombre,strcat(empl,num));
    n=rand()%JEFES_SIZE;
    aux=*jefe_dir;
    for(j=0;j<n;j++)
      aux=aux->sig;    
    strcpy(curr->antecesor,aux->nombre);
    curr->sig=*empl_dir;
    *empl_dir=curr;
  }

  
  return 1;
}
