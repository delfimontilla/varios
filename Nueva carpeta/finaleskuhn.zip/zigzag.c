#include<stdio.h>
#include<stdlib.h>

#define C 4
#define N 4

typedef struct NODO{
	int val;
	struct NODO *prox;
	struct NODO *sig;
}T_NODO;

void crear_vector_de_listas(T_NODO *VE[]);
T_NODO *crear_lista();
void insertar_al_final(T_NODO **l,int val);
void imprimir_vector_de_listas(T_NODO *VE[]);
void imprimir_lista(T_NODO *l);
void enganchar(T_NODO *VE[]);
void diagonal_secundaria(T_NODO* VE[], T_NODO** aux, int* fila,int* columna);
void diagonal_principal(T_NODO* VE[], T_NODO** aux, int* fila,int* columna);
T_NODO* recorrer_hasta(T_NODO* lista, int pos);
void imprimir_lista2(T_NODO *l);

int main()
{
	T_NODO *VE[C];

	crear_vector_de_listas(VE);
	imprimir_vector_de_listas(VE);
	enganchar(VE);
	imprimir_lista2(VE[C-1]);

	return 0;
}

void crear_vector_de_listas(T_NODO *VE[])
{
	int i;

	for(i=0;i<C;i++)
		VE[i]=crear_lista();

}

T_NODO *crear_lista()
{
	T_NODO *l=NULL;
	int i,val;

	for(i=0;i<N;i++)
	{
		val=rand()%10;
		insertar_al_final(&l,val);
	}

	return l;
}

void insertar_al_final(T_NODO **l,int val)
{
	if((*l)==NULL)
	{
		(*l)=(T_NODO *)malloc(sizeof(T_NODO));
		(*l)->val=val;
		(*l)->sig=NULL;
		(*l)->prox=NULL;
	}
	else
	{
		T_NODO *aux=*l;
		while(aux->sig) aux=aux->sig;
		aux->sig=(T_NODO *)malloc(sizeof(T_NODO));
		aux->sig->val=val;
		aux->sig->sig=NULL;
		aux->sig->prox=NULL;
	}
}

void imprimir_vector_de_listas(T_NODO *VE[])
{
	int i;

	for(i=0;i<C;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}
}

void imprimir_lista(T_NODO *l)
{
	T_NODO *aux=l;
	
	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->sig;
	}
}

void imprimir_lista2(T_NODO *l)
{
	T_NODO *aux=l;
	
	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->prox;
	}
}

void enganchar(T_NODO *VE[])
{
	T_NODO *aux=NULL;
	int fila=C-1;
	int columna=1;
	/*printf("la fila es: %d\n",fila);*/
	aux=VE[fila];
	/*printf("la columna es: %d\n",columna);*/
	aux->prox=(VE[fila])->sig;
	aux=aux->prox;
		
	while(fila!=0 || columna!=N-1)
	{
		diagonal_secundaria(VE,&aux,&fila,&columna);
		if(fila==0){
			aux->prox=recorrer_hasta(VE[fila],columna+1);
			columna++;
			aux=aux->prox;
		}
		if(columna==0 && fila!=0){
			aux->prox=recorrer_hasta(VE[fila-1],columna);
			fila--;
			aux=aux->prox;
		}
		if(fila==0 && columna==N-1) return;
		diagonal_principal(VE,&aux,&fila,&columna);
		if(columna==(N-1)){
			aux->prox=recorrer_hasta(VE[fila-1],columna);		
			fila--;
			aux=aux->prox;
		}
		if(fila==(C-1) && columna!=(N-1)){
			aux->prox=recorrer_hasta(VE[fila],columna+1);
			columna++;
			aux=aux->prox;
		}
	}
}

void diagonal_secundaria(T_NODO* VE[], T_NODO** aux, int* fila,int* columna){

	while(((*columna)!=0) && ((*fila)!=0)){
		(*aux)->prox=recorrer_hasta(VE[(*fila)-1],(*columna)-1);
		(*aux)=(*aux)->prox;		
		(*fila)--;
		(*columna)--;
	}
	return;
}
				
void diagonal_principal(T_NODO* VE[], T_NODO** aux, int* fila,int* columna){

	while((*columna)!=(N-1) && (*fila)!=(C-1)){
		(*aux)->prox=recorrer_hasta(VE[(*fila)+1],(*columna)+1);
		(*aux)=(*aux)->prox;
		(*columna)++;
		(*fila)++;
	}
	return;
}

T_NODO* recorrer_hasta(T_NODO* lista, int pos){
	int i;
	T_NODO* aux=NULL;

	aux = lista;
	for(i=0;i<pos;i++){
		aux=aux->sig;
		if(aux == NULL)
			return NULL;
	}

	return aux;
}
