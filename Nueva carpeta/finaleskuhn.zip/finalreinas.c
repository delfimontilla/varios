#include <stdio.h>
#include <stdlib.h>


int puede_comer_otra_reina(int M[][5], int , int , int );
int reinas (int M[][5] , int );

int main (){
	int i;

	int M[5][5]={1,0,0,0,0,0,0,1,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,1,0};
	i=reinas(M,5);
	if(i==0) printf("%s\n","Hay al menos una reina que puede comer a otra");
	else printf("%s\n","No hay ninguna reina que pueda comer a otra");
	return 1;
}

int reinas (int M[][5], int n){

	int i=0,j=0,k=1;
	
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(M[i][j]==1){
				k=puede_comer_otra_reina(M,i,j,n);
				if(k==0) return 0;
			}
		}
	}
	return 1;
}

int puede_comer_otra_reina(int M[][5], int fila, int columna, int n){
	
	int i=0, filaaux=fila, columnaaux=columna;

	for(i=0;i<n;i++){
		if(M[fila][i]==1 && M[fila][i]!=M[fila][columna]) return 0;
		if(M[i][columna]==1 && M[i][columna]!=M[fila][columna]) return 0;
	}
	while(filaaux!=0 && columnaaux!=(n-1)){
		if(M[filaaux-1][columnaaux+1]==1) return 0;
		filaaux--;
		columnaaux++;
	}
	filaaux=fila;
	columnaaux=columna;
	while(filaaux!=(n-1) && columnaaux!=0){
		if(M[filaaux+1][columnaaux-1]==1) return 0;
		filaaux++;
		columnaaux--;
	}
	filaaux=fila;
	columnaaux=columna;
	while(filaaux!=0 && columnaaux!=0){
		if(M[filaaux-1][columnaaux-1]==1) return 0;
		filaaux--;
		columnaaux--;
	}
	filaaux=fila;
	columnaaux=columna;
	while(filaaux!=(n-1) && columnaaux!=(n-1)){
		if(M[filaaux+1][columnaaux+1]==1)return 0;
		filaaux++;
		columnaaux++;
	}
	return 1;
}
	








