#include<stdio.h>
#include<stdlib.h>

#define N 6
#define C 7

typedef struct NODO{
	int val;
	struct NODO *sig;
}T_NODO;

void crear_vector_de_listas(T_NODO *VE[]);
T_NODO *crear_lista();
void insertar_al_final(T_NODO **l,int val);
void imprimir_vector_de_listas(T_NODO *VE[]);
void imprimir_lista(T_NODO *l);
T_NODO *enganchar_en_s(T_NODO *VE[]);
void enganchar_hacia_abajo(T_NODO *VE[]);
void enganchar_hacia_arriba(T_NODO *VE[]);
T_NODO *recorrer_hasta(T_NODO *l,int x);
T_NODO *crear_lista_random();

int main()
{
	T_NODO *VE[N],*l=NULL;

	crear_vector_de_listas(VE);
	imprimir_vector_de_listas(VE);
	l=enganchar_en_s(VE);
	printf("\n");
	imprimir_lista(l);

	return 0;
}

void crear_vector_de_listas(T_NODO *VE[])
{
	int i=0;
	VE[i]=crear_lista();
	for(i=1;i<N-1;i++)
		VE[i]=crear_lista_random();
	VE[N-1]=crear_lista();
}

T_NODO *crear_lista()
{
	T_NODO *l=NULL;
	int i,x;
	
	for(i=0;i<C;i++)
	{
		x=rand()%10;
		insertar_al_final(&l,x);
	}

	return l;
}

T_NODO *crear_lista_random()
{
	T_NODO *l=NULL;
	int i,x,z;
	z=rand()%C;
	for(i=0;i<z;i++)
	{
		x=rand()%10;
		insertar_al_final(&l,x);
	}

	return l;
}

void insertar_al_final(T_NODO **l,int x)
{
	if((*l)==NULL)
	{
		(*l)=(T_NODO *)malloc(sizeof(T_NODO));
		(*l)->val=x;
		(*l)->sig=NULL;
	}
	else
	{
		T_NODO *aux=*l;
		while(aux->sig) aux=aux->sig;
		aux->sig=(T_NODO *)malloc(sizeof(T_NODO));
		aux->sig->val=x;
		aux->sig->sig=NULL;
	}
}

void imprimir_vector_de_listas(T_NODO *VE[])
{
	int i;

	for(i=0;i<N;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}
}

void imprimir_lista(T_NODO *l)
{
	T_NODO *aux=l;

	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->sig;
	}
}

T_NODO *enganchar_en_s(T_NODO *VE[])
{
	T_NODO *aux=VE[0];

	while(VE[0])
	{
		enganchar_hacia_abajo(VE);
		if(VE[0]) enganchar_hacia_arriba(VE);
	}

	return aux;
}

void enganchar_hacia_abajo(T_NODO *VE[])
{
	T_NODO *aux=VE[0];
	int i;

	for(i=0;i<N-1;i++)
	{
		VE[i]=VE[i]->sig;
		aux->sig=recorrer_hasta(VE[i+1],0);
		while(aux->sig==NULL){
			i++;
			aux->sig=recorrer_hasta(VE[i+1],0);
		}
		aux=aux->sig;
	}

	VE[N-1]=VE[N-1]->sig;
}

void enganchar_hacia_arriba(T_NODO *VE[])
{
	T_NODO *aux=VE[N-1];
	int i;

	for(i=N-1;i>0;i--)
	{	
		VE[i]=VE[i]->sig;
		aux->sig=recorrer_hasta(VE[i-1],0);
		while(aux->sig==NULL){
			i--;
			aux->sig=recorrer_hasta(VE[i-1],0);
		}
		aux=aux->sig;
	}

	VE[0]=VE[0]->sig;
}

T_NODO *recorrer_hasta(T_NODO *l,int x)
{
	int i;
	T_NODO *p=l;

	/*if(l!=NULL)
	{
		for(i=0;i<x && p!=NULL;i++)
			p=p->sig;
	}*/

	if(p==NULL) return NULL;
	else return p;
}
