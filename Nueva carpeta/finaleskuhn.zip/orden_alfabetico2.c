#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>

typedef struct nodo{
  char nombre[20];
  struct nodo *sig;
}pers;

pers *crear_lista(char *nombres[]);
void imprimir_lista(pers *lista);
void destruir_lista(pers **lista);
pers *pos_min(pers *lista);
pers *desenganchar(pers *nodo,pers **lista_dir);
void ordenar_alfabeticamente(pers **prim_dir);


int main(void){
  char *nombres[]={"Lauta","Agustin","Santi","Hernán","Luz","Delfi","Ian","Stefi",NULL};
  pers *lista=NULL;

  printf("Ordenar alfabéticamente la siguiente lista de nombres:\n");  
  lista=crear_lista(nombres);
  imprimir_lista(lista);
  printf("\nRespuesta:\n");
  ordenar_alfabeticamente(&lista);
  imprimir_lista(lista);
  destruir_lista(&lista);
  return 1;  
}

pers *pos_min(pers *lista){
  pers *min=NULL;
  if(lista->sig==NULL)
    return lista;
  else{
    min=pos_min(lista->sig);
    if(strcmp(lista->nombre,min->nombre)<0)
      return lista;
    else
      return min;
  }  
}

pers *desenganchar(pers *nodo,pers **lista_dir){
  if((*lista_dir)==nodo){
    (*lista_dir)=nodo->sig;
    nodo->sig=NULL;
  }
  else
    desenganchar(nodo,&((*lista_dir)->sig));
  return nodo;  
}

void ordenar_alfabeticamente(pers **prim_dir){
  pers *min=NULL, *aux=NULL;
  if((*prim_dir)->sig!=NULL){
    min=pos_min(*prim_dir);
    min=desenganchar(min,prim_dir);
    aux=*prim_dir;
    *prim_dir=min;
    min->sig=aux;
    ordenar_alfabeticamente(&((*prim_dir)->sig));
  }
}

pers *crear_lista(char *nombres[]){
  pers *head=NULL,*curr=NULL;
  int i=0;  
  
  for(i=0;nombres[i]!=NULL;i++){
    if((curr=(pers *)malloc(sizeof(pers)))==NULL)
      return NULL;
    strcpy(curr->nombre,nombres[i]);
    curr->sig=head;
    head=curr;
  }
  return head;
}

void imprimir_lista(pers *lista){
  pers *aux=lista;
  while(aux->sig!=NULL){
    printf("%s - ",aux->nombre);
    aux=aux->sig;
  }
  printf("%s\n",aux->nombre);
  
}

void destruir_lista(pers **lista){
  pers *aux=*lista; 
  while(aux!=NULL){
    *lista=aux->sig;
    free(aux);
    aux=*lista;
  }
}
