#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#define PADRES_SIZE 3
#define HIJOS_SIZE PADRES_SIZE*2
#define EMPLEADOS_SIZE HIJOS_SIZE*2

typedef struct persona{

  char nombre[20];
  char antecesor[20];
  struct persona * sig;
} pers;

void reverse(char s[]);
void itoa(int n, char s[]);
int crear_lista_familia(pers **padr_dir,pers **HIJO_dir);
void enganchar(pers **PADRES, pers *HIJOS);
pers *buscar_HIJO_de(char *s,pers **lista);

void imprimir_lista(pers *head);


int main (void){
	pers *PADRES=NULL, *HIJOS=NULL;
	srand(time(NULL));

	/*Se crean las listas de PADRES, HIJOS y EMPLEADOS.*/
	crear_lista_familia(&PADRES, &HIJOS);
	
	imprimir_lista(PADRES);
	imprimir_lista(HIJOS);

	enganchar(&PADRES,HIJOS);
	putchar('\n');
	imprimir_lista(PADRES);
 
    
	return 1;
}

void enganchar(pers **PADRES, pers *HIJO_dir){
  pers *aux0=NULL, *aux1=*PADRES, *aux2=NULL, *aux3=NULL;

  while(aux1!=NULL){
    aux2=aux1->sig;
    aux3=buscar_HIJO_de(aux1->nombre,&HIJO_dir);
    while(aux3!=NULL){
      aux3->sig=aux1->sig;
      aux1->sig=aux3;
      aux3=buscar_HIJO_de(aux1->nombre,&HIJO_dir);
    }
    while(aux1->sig!=aux2)
    aux1=aux1->sig;
    aux1=aux2;
  }  
}


pers *buscar_HIJO_de(char *s,pers **lista){
  pers *aux1=*lista, *aux2=*lista;

  if(aux1==NULL)
    return NULL;
  if(!strcmp((*lista)->antecesor,s)){
    *lista=aux2->sig;
    aux2->sig=NULL;
    return aux2;
  }
  while(aux2!=NULL){
    if(strcmp(aux2->antecesor,s))
      aux2=aux2->sig;
    else
      break;
  }
  if(aux2==NULL)
    return NULL;
  while(aux1->sig!=aux2)
    aux1=aux1->sig;
  aux1->sig=aux2->sig;
  aux2->sig=NULL;
  return aux2;
}







int crear_lista_familia(pers **padr_dir, pers **HIJO_dir){
  char padr[10]="PADRE", HIJO[10]="HIJO", num[10]="99";
  pers *curr=NULL,*aux=NULL;
  int i=0, j=0, n=0;
  *padr_dir=NULL;
  for(i=PADRES_SIZE;i>0;i--){
    if((curr=(pers *)malloc(sizeof(pers)))==NULL)
      return -1;
    itoa(i,num);
    strcpy(padr,"PADRE");
    strcpy(curr->nombre,strcat(padr,num));
    strcpy(curr->antecesor,"");
    curr->sig=*padr_dir;
    *padr_dir=curr;
  }
  for(i=HIJOS_SIZE;i>0;i--){
    if((curr=(pers *)malloc(sizeof(pers)))==NULL)
      return -1;
    itoa(i,num);
    strcpy(HIJO,"HIJO");
    strcpy(curr->nombre,strcat(HIJO,num));
    n=rand()%PADRES_SIZE;
    aux=*padr_dir;
    for(j=0;j<n;j++)
      aux=aux->sig;    
    strcpy(curr->antecesor,aux->nombre);
    curr->sig=*HIJO_dir;
    *HIJO_dir=curr;
  }
  return 1;
}

void reverse(char s[]){
  int c=0,i=0,j=0;
  for(i=0,j=strlen(s)-1;i<j;i++,j--){
    c=s[i];
    s[i]=s[j];
    s[j]=c;
  }
}


void itoa(int n, char s[]){
  int i=0;
  do{
    s[i++]=n%10+'0';
  }while((n/=10)>0);
  s[i]='\0';
  reverse(s);
}

void imprimir_lista(pers *head){
  pers *aux=head;

  while(aux!=NULL){
    printf("Nombre: %s \t\t Antecesor: %s\n",aux->nombre,aux->antecesor);
    aux=aux->sig;
  }    
}

