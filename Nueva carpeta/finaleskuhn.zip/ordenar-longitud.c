#include<stdio.h>
#include<stdlib.h>

#define N 5	/*es la cantidad de listas del vector*/

typedef struct NODO{
	int val;
	struct NODO *sig;
}T_NODO;

T_NODO *crear_lista(void);
void insertar_al_final(T_NODO **l,int val);
void imprimir_lista(T_NODO *l);
void ordenar_segun_cantidad(T_NODO *VE[N]);
int cantidad_de_elementos_de_lista(T_NODO *l);

int main(void)
{
	T_NODO *VE[N];
	int i;

	for(i=0;i<N;i++)
		VE[i]=crear_lista();
	
	printf("\n");
	/*primero imprimo la lista tal cual la cree*/
	for(i=0;i<N;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}

	ordenar_segun_cantidad(VE);

	printf("\n");
	/*ahora la imprimo ordenada*/
	for(i=0;i<N;i++)
	{
		imprimir_lista(VE[i]);
		printf("\n");
	}

	return 0;
}

T_NODO *crear_lista(void)
{
	T_NODO *l=NULL;
	int i,val,cant;

	printf("Ingrese cantidad de elementos: \n");
	scanf("%d",&cant);

	printf("Ingrese numeros: \n");
	for(i=0;i<cant;i++)
	{
		scanf("%d",&val);
		insertar_al_final(&l,val);
	}

	return l;
}

void insertar_al_final(T_NODO **l,int val)
{
	if((*l)==NULL)
	{
		(*l)=(T_NODO *)malloc(sizeof(T_NODO));
		(*l)->val=val;
		(*l)->sig=NULL;
	}
	else
	{
		T_NODO *aux=*l;
		while(aux->sig) aux=aux->sig;

		aux->sig=(T_NODO *)malloc(sizeof(T_NODO));
		aux->sig->val=val;
		aux->sig->sig=NULL;
	}
}

void imprimir_lista(T_NODO *l)
{
	T_NODO *aux=l;

	while(aux)
	{
		printf("%d ",aux->val);
		aux=aux->sig;
	}
}
/*Lo ordeno por el metodo del burbujeo*/
void ordenar_segun_cantidad(T_NODO *VE[])
{
	int i,j;
	T_NODO *aux=NULL;
	
	for(j=0;j<=N-2;j++)
	{
		for(i=0;i<N-1-j;i++)
		{
			if(cantidad_de_elementos_de_lista((VE)[i+1])<cantidad_de_elementos_de_lista((VE)[i]))
			{
				aux=(VE)[i];
				(VE)[i]=(VE)[i+1];
				(VE)[i+1]=aux;
			}
		}
	}
}


int cantidad_de_elementos_de_lista(T_NODO *l)
{
	int i,cant=0;
	T_NODO *aux=l;

	while(aux)
	{
		aux=aux->sig;
		cant++;
	}

	return cant;
}
