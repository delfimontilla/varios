/*
  Métodos básicos de ordenamiento (burbujeo, selección e inserción).
*/


#include <stdio.h>
#include <stdlib.h>
#include <time.h>


void insercion(int V[], int size);
void seleccion(int V[], int size);
void burbujeo(int V[], int size);
int *vector_aleatorio(int size);
void imprimir_vector(int *V,int size);
void swap(int *a, int *b);



int main(void){
  int size=8,*V=NULL;
  srand(time(NULL));

  /*Se crea un vector de enteros aleatorios de tamaño "size" */
  V=vector_aleatorio(size);
  imprimir_vector(V,size);
  /*insercion(V,size);*/
  /*seleccion(V,size);*/
  burbujeo(V,size);
  imprimir_vector(V,size);
  free(V);
  return 0;
}


int *vector_aleatorio(int size){
  int i=0, *V=NULL;
  if((V=(int *)malloc(sizeof(int)*size))==NULL)
    return NULL;
  for(i=0;i<size;i++)
    V[i]=rand()%100+1;
  return V;
}

void insercion(int V[], int size){
  int i=0,j=2;
  
  while(j<=size){
    i=j-1;
    while(V[i]<V[i-1] && i>0){
      swap(&V[i],&V[i-1]);
      i--;
    }
    j++;
  }
}


void imprimir_vector(int *V,int size){
  int i=0;
  for(i=0;i<size;i++)
    printf("%d ",V[i]);
  putchar('\n');
}

void seleccion(int V[], int size){
  int i=0,j=0,posmin=0;

  while(j<size){
    i=posmin=j;
    while(i<size){
      if(V[i]<V[posmin])
	posmin=i;
      i++;
    }
    swap(&V[j],&V[posmin]);
    j++;
  }
}

void burbujeo(int V[], int size){
  int i=0,j=0;
  
  for(j=0;j<size;j++){
    for(i=0;i<size-1-j;i++){
      if(V[i+1]<V[i])
	swap(&V[i],&V[i+1]);
    }
  }
}
	    

	     
void swap(int *a, int *b){
  int c=*a;
  *a=*b;
  *b=c;
}
