#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>
#include <time.h>

typedef struct NODO{
	char* subexpr;
	struct NODO *sig;
}T_NODO;


T_NODO *separa_expresiones (char*);
void cadena_a_lista(char*,int,T_NODO**);
void insertar_al_final (T_NODO**, char*, int,int);
void subexpresion (T_NODO*, char*, int, int);
void imprimir_lista(T_NODO*);

int main(void){ 

	T_NODO *VE=NULL;
	char cadena[100];
	
	printf("Ingrese la cuenta con al menos un parentesis\n");
	fgets(cadena,100,stdin);
	cadena[strlen(cadena)-1]='\0';
	printf("La cadena es %s\n",cadena);
	VE=separa_expresiones(cadena);
	imprimir_lista(VE);
	printf("\n");
	return 0;
}



T_NODO *separa_expresiones (char* cadena) {

	int i,k=0;
	T_NODO* puntero_devuelto=NULL;

	for(i=0;cadena[i]!='\0';i++){
		
		if(cadena[i]=='('){			
			k=i;
			cadena_a_lista(cadena,k+1,&puntero_devuelto);
		}	

	}
	return puntero_devuelto;
}

void cadena_a_lista (char* cadena, int l, T_NODO** puntero_devuelto){
	
	int i=0, j, k=0, paren=1;
	
	for(i=l; paren!=0 && cadena[i]!='\0' && cadena[i]!='\n'; i++){
		if(cadena[i]=='('){
			paren++;
		}
		else if(cadena[i]==')'){
			paren--;
		}
	}
	for( j=l; j!=i-1;j++){
		k++;
	}
	
	insertar_al_final (puntero_devuelto,cadena,l,k);

}

void insertar_al_final (T_NODO** l, char* cadena, int empieza,int caracteres_seguidos){
	T_NODO* aux=NULL;
	if((*l)==NULL){
		(*l)=(T_NODO*)malloc(sizeof(T_NODO));
		(*l)->sig=NULL;
		subexpresion((*l),cadena,empieza,caracteres_seguidos);
	}else{
		aux=(*l);	
		while(aux->sig) aux=aux->sig;
		aux->sig= (T_NODO*) malloc (sizeof(T_NODO));
		aux->sig->sig=NULL;
		subexpresion(aux,cadena,empieza,caracteres_seguidos);
	}
}

void subexpresion (T_NODO* aux, char* cadena, int empieza,int caracteres_seguidos){
	int k=0,z=0;
	if((aux->sig)==NULL){
		aux->subexpr=(char*)malloc((sizeof(char)*caracteres_seguidos)+1);
		for(k=empieza;z<caracteres_seguidos;k++){
			(aux->subexpr)[z]=cadena[k];
			z++;
		}
	} else{
		aux->sig->subexpr=(char*)malloc((sizeof(char)*caracteres_seguidos)+1);
		for(k=empieza;z<caracteres_seguidos;k++){
			(aux->sig->subexpr)[z]=cadena[k];
			z++;
		}
	}
}

void imprimir_lista(T_NODO* VE){

	T_NODO *aux=VE;
	
	while(aux)
	{
		printf("%s\n",aux->subexpr);
		aux=aux->sig;
	}
}
