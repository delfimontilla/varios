#ifndef TIPOS__H
#define TIPOS__H

typedef enum {

	ST_OK,
	ST_ERROR,
	ST_OPCION_INVALIDA,
	ST_PUNTERO_NULO,
	ST_SIN_CARRERA

} status_t;

#endif