#ifndef IDIOMA__H
#define IDIOMA__H

#include "setup.h"
#ifdef LANG_ESP
#include "espannol.h"
#else
#include "ingles.h"

#endif
#endif