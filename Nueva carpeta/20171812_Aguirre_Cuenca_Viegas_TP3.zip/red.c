#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "listas.h"
#include "status.h"
#include "usuarios.h"
#include "mensajes.h"
#include "utilidades.h"
#include "idioma.h"
#include "red.h"


int main (int argc, char * argv []){

	lista_s usuarios;
	usuario_s usuario_buscado;
	status_t status;
	operation_t op;
	indicador_filtro_t ind;
	bool_t bool;
	FILE *fin, *fout;
	retval_t rv;
	size_t i;
	usuario_s * usuario;

	if((status = validar_argumentos(argc, argv, &usuario_buscado, &op, &ind)) != ST_OK){
		handle_error(status);
		return EXIT_FAILURE;
	}

	if((rv = lista_crear(&usuarios)) != RV_OK){
            return EXIT_FAILURE;
		}

	for(i = 0 ;i < (argc - MIN_ARG_VALUE + 1) ; i++){

        if((fin = fopen(argv[ARG_POS_ARCHIVO + i], "rt" )) == NULL){
            return ST_ERROR_ARCHIVO_CORRUPTO;
        }

		do{
			usuario = cargar_usuario(fin, &status);
			lista_insertar_final(&usuarios, (void*) usuario);
		}while(status == ST_OK);

		if(!feof(fin)){
			destruir_lista (&usuarios, (void (*)(void *)) del_usuario);
			fclose(fin);
			return EXIT_FAILURE;
		}

		if (status != ST_OK && status != ST_FIN_ARCHIVO){
			destruir_lista (&usuarios, (void (*)(void *)) del_usuario);
			handle_error(status);
			fclose(fin);
            return EXIT_FAILURE;
		}
    	fclose(fin);
	}

	switch (ind){

		case IND_ID:

    		if((bool = eliminar_dato(&usuarios, (void*) &usuario_buscado, (int(*)(void*, void*))cmp_id, (void(*)(void*))del_usuario)) != TRUE){
				fprintf(stderr, "%s\n", MSJ_USUARIO_INEXISTENTE);
			}
			break;


		case IND_APODO:

			if((bool = eliminar_dato(&usuarios, (void*) &usuario_buscado, (int(*)(void*, void*))cmp_apodo, (void(*)(void*))del_usuario)) != TRUE){
				fprintf(stderr, "%s\n", MSJ_USUARIO_INEXISTENTE);
			}
			break;

		default:
			destruir_lista (&usuarios, (void (*)(void *)) del_usuario);
			break;
	}

	switch (op){

    	case OP_IMPRIMIR_STDOUT:

        	if((rv = lista_recorrer(usuarios, (void(*)(void*,void*))imprimir_usuario, stdout)) != RV_OK){
        		destruir_lista (&usuarios, (void (*)(void *)) del_usuario);
            	return EXIT_FAILURE;
        	}
    		break;

    	case OP_IMPRIMIR_MULTI:

        	if((rv = lista_recorrer(usuarios, (void(*)(void*,void*))guardar_usuario, &fout)) != RV_OK){
     			destruir_lista (&usuarios, (void (*)(void *)) del_usuario);
            	return EXIT_FAILURE;
        	}
    		break;

 		default:
    		destruir_lista (&usuarios, (void (*)(void *)) del_usuario);
        	handle_error(status);
        	return EXIT_FAILURE;
    }
    
    destruir_lista (&usuarios, (void (*)(void *)) del_usuario);

	return EXIT_SUCCESS;
}

status_t validar_argumentos (int argc, char * argv[], usuario_s * buscado, operation_t * op, indicador_filtro_t * indicador){

	char * endptr;

	if(!argv || !buscado){
		return ST_ERROR_PUNTERO_NULO;
	}

	if(argc < MIN_ARG_VALUE){
		return ST_ERROR_ARGUMENTO_INVALIDO;
	}

    if((strcmp(argv[OPERACION_POS], OP_ELIMINAR_1)) != 0 && strcmp(argv[OPERACION_POS], OP_ELIMINAR_2) != 0){
    	return ST_ERROR_ARGUMENTO_INVALIDO;
    }

    switch((argv[FILTRO_POS])[0]){

        case INDICADOR_ID:
            buscado->id = (int)strtol((argv[FILTRO_POS]) + 2, &endptr, 10);
            if(*endptr != '\0')
                return ST_ERROR_ARGUMENTO_INVALIDO;
            *indicador = IND_ID;
            break;

        case INDICADOR_APODO:
            if(( buscado->apodo = (char*) malloc (sizeof(char) * (strlen(argv[FILTRO_POS]) - 1))) == NULL)
                return ST_ERROR_MEMORIA;
            strcpy(buscado->apodo, (argv[FILTRO_POS])+2);
            *indicador = IND_APODO;
            break;

        default:
            return ST_ERROR_ARGUMENTO_INVALIDO;
    }


    if((strcmp(argv[POS_OUTPUT_OP], OP_OUTPUT_1)) != 0 && strcmp(argv[POS_OUTPUT_OP], OP_OUTPUT_2) != 0){
    	return ST_ERROR_ARGUMENTO_INVALIDO;
    }

    if((strcmp(argv[OUTPUT_POS_MODO], INDICADOR_SINGLE)) == 0){
    	*op = OP_IMPRIMIR_STDOUT;
    	return ST_OK;
    }
    else{
        if((strcmp(argv[OUTPUT_POS_MODO], INDICADOR_MULTI)) == 0){
        	*op = OP_IMPRIMIR_MULTI;
        	return ST_OK;
        }
        else{
        	return ST_ERROR_ARGUMENTO_INVALIDO;
        }
    }
}
