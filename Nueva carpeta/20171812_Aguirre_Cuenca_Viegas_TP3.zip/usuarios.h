#ifndef USUARIOS__H
#define USUARIOS__H

#include "listas.h"
#include "mensajes.h"
#include "vector.h"

#define AMIGOS_POS 9
#define NOMBRE_POS 9
#define ID_POS 5
#define APODO_POS 1
#define CORCHETE_INICIAL '['
#define CORCHETE_FINAL ']'
#define IGUAL_DELIM '='
#define MSJ_ID "id"
#define MSJ_NOMBRE "nombre"
#define MSJ_AMIGOS "amigos"
#define MSJ_MENSAJE "mensaje"
#define SALTO_DE_LINEA "\n"
#define ESPACIO ' '


typedef struct usuario {

	int id;
	char * nombre;
	char * apodo;
	vector_s * amigos;
	lista_s mensaje;

}usuario_s;

usuario_s * cargar_usuario(FILE * fin, status_t * st);
void del_usuario (usuario_s * usuario);
int cmp_id (const usuario_s * usuario,const usuario_s * buscado);
int cmp_apodo (const usuario_s * usuario, const usuario_s * buscado);
void imprimir_usuario(usuario_s * usuario, FILE * stream);
status_t guardar_usuario(usuario_s * u);



#endif
