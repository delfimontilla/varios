#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

#include "vector.h"
#include "status.h"

vector_s * vector_crear(size_t size){

	vector_s * v;

	if((v = (vector_s*)calloc(1, sizeof(vector_s))) == NULL)
		return NULL;

	if((v->datos = (void**) malloc (size * sizeof(void*))) == NULL){
		free(v);
		return NULL;
	}

	v->alloc = size;
	v->used = 0;

	return v;
}

void vector_destruir(vector_s ** v){

	size_t i;

	if (v && *v){
		for( i = 0; i < (*v)->used; i++){
			free(((*v)->datos)[i]);
			((*v)->datos)[i] = NULL;
		}
		free((*v)->datos);
		(*v)->datos = NULL;
		free(*v);
		*v = NULL;
	}
}

bool_t vector_isempty(const vector_s * v){

	assert(v != NULL);
	return v->used == 0;
}

bool_t vector_insertar_al_final (vector_s * v, void * dato){

	void ** aux;

	if(!v)
		return FALSE;

	if(v->used == v->alloc){
		if((aux = (void**)realloc(v->datos, (v->alloc + CHOP_SIZE) * sizeof(void*))) == NULL)
			return FALSE;

		v->datos = aux;
		v->alloc += CHOP_SIZE;
	}

	v->datos[v->used++] = dato;

	return TRUE;
}

void * vector_obtener (const vector_s * v, int i){

	if(!v || !v->used)
		return NULL;

	if(i < v->used && i >= 0)
		return v->datos[i];

	else if (i < 0 && -i < v->used){
		return v->datos[v->used+i];
	}

	return NULL;
}

size_t vector_largo (vector_s * v){

    return v->used;
}
