#ifndef VECTOR__H
#define VECTOR__H

#include <stdio.h>
#include "status.h"

#define CHOP_SIZE 5

typedef struct vector{
	size_t alloc;
	size_t used;
	void ** datos;

}vector_s;

vector_s * vector_crear(size_t size);
void vector_destruir(vector_s ** v);
bool_t vector_isempty(const vector_s * v);
bool_t vector_insertar_al_final (vector_s * v, void * dato);
void * vector_obtener (const vector_s * v, int i);
size_t vector_largo (vector_s * v);

#endif
