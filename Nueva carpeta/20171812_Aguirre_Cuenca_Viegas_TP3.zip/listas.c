#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "listas.h"
#include "status.h"

bool_t lista_esta_vacia (lista_s l){

	return l == NULL;
}

retval_t lista_crear (lista_s *pl){

	if(!pl)
		return RV_ILLEGAL;

	*pl = NULL;
	return RV_OK;
}

retval_t lista_crear_nodo (nodo_t **pnodo, void *dato){

	if(pnodo == NULL)
		return RV_ILLEGAL;

	if((*pnodo = (nodo_t*) calloc (1,sizeof(nodo_t))) == NULL){
		return RV_NO_SPACE;
	}

	(*pnodo)->sig = NULL;
	(*pnodo)->dato = dato;
	return RV_OK;
}

retval_t lista_destruir_nodo (nodo_t ** pnodo, void (*destructor)(void *)){

	if(!pnodo || !destructor){
		return RV_ILLEGAL;
	}

	(*destructor)((*pnodo)->dato);
	(*pnodo)->dato = NULL;
	(*pnodo)->sig = NULL;
	free(*pnodo);
	return RV_OK;
}

retval_t destruir_lista ( lista_s * pl, void (* destructor)(void*)){

	nodo_t * primero;

	if(!pl)
		return RV_ILLEGAL;

	while (!lista_esta_vacia(*pl)){

		primero = *pl;
		*pl = (*pl)->sig;
		lista_destruir_nodo(&primero,destructor);
	}
	return RV_OK;
}

retval_t lista_insertar_final (lista_s * pl, void * dato){

	if(!pl){
		return RV_ILLEGAL;
	}

	if (lista_esta_vacia(*pl)){

		return lista_insertar_ppio (pl,dato);
	}

	return lista_insertar_final(&((*pl)->sig),dato);

}

retval_t lista_insertar_ppio (lista_s *pl, void * dato){

	retval_t rv;
	nodo_t * nodo;

	if (!pl){
		return RV_ILLEGAL;
	}

	if((rv = lista_crear_nodo(&nodo,dato)) != RV_OK)
		return rv;

	nodo->sig = *pl;
	*pl = nodo;

	return RV_OK;
}

retval_t lista_recorrer (lista_s l, void (*pf)(void *, void*), void * arg){

    if(pf == NULL)
        return RV_ILLEGAL;

    while(l != NULL){
        (*pf)(l->dato, arg);
        l = l->sig;
    }

    return RV_OK;
}

bool_t eliminar_dato(lista_s * pl, void * buscado, int (*cmp) (void*, void*), void (*destructor)(void*)){

    lista_s anterior, lista_aux;

    if(!cmp || !pl)
        return FALSE;

    anterior = *pl;
    lista_aux = *pl;

    do{
        if((*cmp)(lista_aux->dato,buscado) == 0){

            if(!(lista_aux->sig)){                              /*si es el ultimo nodo*/
            	lista_destruir_nodo(&lista_aux, destructor);
            	anterior->sig = NULL;
                return TRUE;
            }
            else{
                if(anterior == lista_aux){
                    /*
                    if(!(lista_aux->sig)){                   obs: es el primer y ultimo nodo, entonces le paso pl.
                        lista_destruir_nodo(pl, destructor); pero al destruir ese nodo falla el programa.
                        return TRUE;
                    }*/

                    *pl = lista_aux->sig;
                    lista_destruir_nodo(&lista_aux, destructor);
                    return TRUE;
                }

                anterior->sig = lista_aux->sig;
                lista_destruir_nodo(&lista_aux, destructor);
                return TRUE;
            }
        }
        else{
            anterior = lista_aux;                       /*redundante para el primer nodo*/
            lista_aux = lista_aux->sig;
        }

    }while( lista_aux != NULL);

    return FALSE;
}

nodo_t * lista_buscar (lista_s pl, void * t, int (*cmp)(void *,void*)){

	if(!pl || !cmp)
		return NULL;

	while(pl != NULL){
		if(!(cmp(t, pl->dato)))
			return pl;

		pl = pl->sig;
	}

	return NULL;
}
