#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "listas.h"
#include "status.h"
#include "usuarios.h"
#include "mensajes.h"
#include "utilidades.h"
#include "config.h"

void del_mensaje(mensaje_s * mensaje){

	if(!mensaje)
		return;

	free(mensaje);
	
}

mensaje_s* cargar_mensaje(char line[MAX_STR], status_t * st){

	size_t n, i;
	char *endptr;
	char line_aux[MAX_STR], ** csv_fields;
	mensaje_s *mensaje;
	struct tm date;

	if((mensaje = (mensaje_s *)malloc(sizeof(mensaje_s))) == NULL){
		*st = ST_ERROR_MEMORIA;
		return NULL;
	}

	for(n = 1, i = 0; n < 4; i++){
		if(line[i] == CHAR_CSV_FIELD_SEPARATOR){
			n++;
		}
		line_aux[i] = line[i];
	}

	line_aux[--i] = '\0';

	if((*st = split(line_aux, CHAR_CSV_FIELD_SEPARATOR, &csv_fields, &n)) != ST_OK){
		del_mensaje(mensaje);
		return NULL;
	}

	mensaje->id_mensaje = (int)strtol(csv_fields[ID_MENSAJE_POS], &endptr, 10);
	if(*endptr != '\0'){
        del_mensaje(mensaje);
		*st = ST_ERROR_DATO_INVALIDO;
        return NULL;
    }

    mensaje->id_usuario = (int)strtol(csv_fields[ID_USUARIO_POS], &endptr, 10);
    if(*endptr != '\0'){
        del_mensaje(mensaje);
		*st = ST_ERROR_DATO_INVALIDO;
        return NULL;
    }

    /* Asigno fecha*/
	if((mensaje->fecha = mktime(transform_date(&date, csv_fields[DATE_FIELD_POS]))) == -1){
		del_mensaje(mensaje);
		return NULL;
	}

	del_array(&csv_fields,&n);

	strcpy(mensaje->texto,line + strlen(line_aux) +1);

	return mensaje;
}

void imprimir_mensaje (mensaje_s * mensaje, FILE * stream){

	struct tm *timeptr;
	char year_aux[LONG_YEAR+1];
	char day_aux[LONG_DAY+1];
	char month_aux[LONG_MONTH+1];

	if((fprintf(stream, "%s" , MSJ_MENSAJE)) == -1)
		return;

	if((fprintf(stream, " %c ",IGUAL_DELIM )) == -1)
		return;

	if((fprintf(stream, "%d", mensaje->id_mensaje)) == -1)
		return;

	if((fprintf(stream, "%c", CSV_DELIM)) == -1)
		return;

	if(!(timeptr = localtime(&(mensaje->fecha))))
		return;

	if(!(strftime(year_aux, LONG_YEAR +1, "%Y", timeptr)))
		return;

	if((fprintf(stream, "%s" , year_aux)) == -1)
		return;

	if((fprintf(stream, "%c" , DATE_DELIM)) == -1)
		return;

	if(!(strftime(month_aux, LONG_MONTH + 1, "%m", timeptr)))
		return;

	if((fprintf(stream, "%s" , month_aux)) == -1)
		return;

	if((fprintf(stream, "%c" , DATE_DELIM)) == -1)
		return;

	if(!(strftime(day_aux, LONG_DAY + 1, "%d", timeptr)))
		return;

	if((fprintf(stream, "%s" , day_aux)) == -1)
		return;

	if((fprintf(stream, "%c", CSV_DELIM)) == -1)
		return;

	if((fprintf(stream, "%d", mensaje->id_usuario)) == -1)
		return;

	if((fprintf(stream, "%c", CSV_DELIM)) == -1)
		return;

	if((fprintf(stream, "%s\n" , mensaje->texto)) == -1)
		return;

}
