#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "utilidades.h"
#include "status.h"

#define LONG_DAY 2
#define LONG_MONTH 2
#define LONG_YEAR 4

#define POS_DAY 8
#define POS_MONTH 5
#define POS_YEAR 0

#define DATE_DELIM '-'


struct tm* transform_date (struct tm * fecha, char * date_str){

	char day[LONG_DAY+1], month[LONG_MONTH+1], year[LONG_YEAR+1];
	char * endptr;

	if( !fecha || !date_str)
		return NULL;

	strncpy(day, date_str + POS_DAY, LONG_DAY);
	day[LONG_DAY] = '\0';

	fecha->tm_mday = strtol(day, &endptr, 10);
	if (*endptr != '\0')
		return NULL; 

	strncpy(month, date_str + POS_MONTH, LONG_MONTH);
	month[LONG_MONTH] = '\0';

	fecha->tm_mon = strtol(month, &endptr, 10) -1;
	if (*endptr != '\0')
		return NULL; 
		
	strncpy(year, date_str + POS_YEAR, LONG_YEAR);
	year[LONG_YEAR] = '\0';

	fecha->tm_year = strtol(year, &endptr, 10) - 1900;
	if (*endptr != '\0')
		return NULL; 
		
	fecha->tm_sec = 0;
	fecha->tm_min = 0;
	fecha->tm_hour = 0;
	fecha->tm_wday = 0;
	fecha->tm_yday = 0;
	fecha->tm_isdst = 0;

	return fecha;
}

status_t split(const char *s, char delim, char ***str_array, size_t *l){

	char **string;
	size_t n, i;
	char *field, *line;
	char *aux;
	char sdelim[2];

	if(!s || !str_array || !l){
		 return ST_ERROR_PUNTERO_NULO;
	}

	for( n = 1, i = 0; s[i]; i++){
		if(s[i] == delim){
			 n++;
		}
	}

	if((string = (char **)malloc(n * sizeof(char *))) == NULL){
		return ST_ERROR_MEMORIA;
	}

	if((line = strdup(s)) == NULL){
		free(string);
		return ST_ERROR_MEMORIA;
	}

	sdelim[0] = delim;
	sdelim[1] = '\0';

	aux = line;
	field = strtok(aux, sdelim);
	for(i = 0; field != NULL; i++){
		if((string[i] = strdup(field)) == NULL){
			free(line);
			del_array(&string, &i);
			*str_array = NULL;
			*l = 0;
			return ST_ERROR_MEMORIA;
		}
		field = strtok(NULL, sdelim);
	}

	free(line);
	*l = n;
	*str_array = string;

	return ST_OK;
}

status_t del_array(char *** s_array, size_t *l){

	size_t i;

	if( !s_array || !l ){
		return ST_ERROR_PUNTERO_NULO;
	}

	for( i = 0; i < *l; i++){
		free((*s_array)[i]);
		(*s_array)[i] = NULL;
	}

	free(*s_array);
	*s_array = NULL;
	*l = 0;

	return ST_OK;
}

char * strdup(const char *s){

	char *s2;

	if( !s)
		return NULL;

	if((s2 = (char *) malloc((strlen(s) +1))) == NULL)
		return NULL;

	strcpy(s2, s);

	return s2;
}

int * intdup(const int i){

	int *i2;

	if((i2 = (int *) malloc(sizeof(int))) == NULL)
		return NULL;

	*i2 = i;

	return i2;
}
