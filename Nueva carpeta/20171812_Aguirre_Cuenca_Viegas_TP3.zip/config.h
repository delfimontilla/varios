#ifndef CONFIG__H
#define CONFIG__H

#define LANG_SPANISH

#define CSV_DELIM ','

#endif