#ifndef LISTAS__H
#define LISTAS__H

#include <stdio.h>
#include <stdlib.h>
#include "status.h"

typedef struct nodo{

	struct nodo * sig;
	void * dato;

}nodo_t, *lista_s;

typedef enum retval {

	RV_OK,
	RV_NO_SPACE,
	RV_ILLEGAL

}retval_t;


bool_t lista_esta_vacia (lista_s);
retval_t lista_crear (lista_s *);
retval_t lista_crear_nodo (nodo_t **, void *);
retval_t lista_destruir_nodo (nodo_t **, void (*destructor)(void *));
retval_t destruir_lista (lista_s *, void(* destructor)(void *));
retval_t lista_insertar_ppio (lista_s *, void *);
retval_t lista_insertar_final (lista_s * pl, void * dato);
retval_t lista_recorrer (lista_s l, void (*pf)(void *, void*), void * arg);
bool_t eliminar_dato(lista_s * pl, void * buscado, int (*cmp) (void*, void*), void (*destructor)(void*));
nodo_t * lista_buscar (lista_s pl, void * t, int (*cmp)(void *,void*));

#endif
