#ifndef ENGLISH__H
#define ENGLISH__H

#define MSG_ERROR_PREFIX "Error"

#define MSG_ERROR_NO_MEMORY "Not enough memory."
#define MSG_ERROR_NULL_POINTER "Null pointer."
#define MSG_ERROR_OPEN_FILE "Failed to open file."
#define MSG_ERROR_INVALID_ARG "Invalid argument."
#define MSG_ERROR_INVALID_DATA "Invalid data."
#define MSJ_USUARIO_INEXISTENTE "Inexistent user."
#define MSG_ERROR_FORMATO "Format error"

#endif