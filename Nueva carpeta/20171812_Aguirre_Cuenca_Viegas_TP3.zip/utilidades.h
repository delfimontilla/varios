#ifndef UTILIDADES__H
#define UTILIDADES__H

#include <stdlib.h>
#include <time.h>

#include "status.h"

#define MAX_STR 140
#define CHAR_CSV_FIELD_SEPARATOR ','

status_t split(const char *s, char delim, char ***str_array, size_t *l);
status_t del_array(char ***s_array, size_t *l);
char* strdup(const char *s);
int * intdup(const int i);
struct tm* transform_date (struct tm * fecha, char * date_str);

#endif