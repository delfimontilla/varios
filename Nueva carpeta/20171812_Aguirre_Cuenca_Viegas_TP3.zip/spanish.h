#ifndef SPANISH__H
#define SPANISH__H

#define MSG_ERROR_PREFIX "Error"

#define MSG_ERROR_NO_MEMORY "No hay memoria suficiente"
#define MSG_ERROR_NULL_POINTER "Puntero nulo"
#define MSG_ERROR_OPEN_FILE "No se pudo abrir el archivo"
#define MSG_ERROR_INVALID_ARG "Argumento inválido."
#define MSG_ERROR_INVALID_DATA "Dato inválido."
#define MSJ_USUARIO_INEXISTENTE "Usuario inexistente."
#define MSG_ERROR_FORMATO "Error formato"


#endif
