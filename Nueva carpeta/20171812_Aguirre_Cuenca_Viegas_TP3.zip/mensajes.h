#ifndef MENSAJES__H
#define MENSAJES__H

#include <time.h>

#include "utilidades.h"
#include "listas.h"

#define LONG_DAY 2
#define LONG_MONTH 2
#define LONG_YEAR 4

#define POS_DAY 8
#define POS_MONTH 5
#define POS_YEAR 0

#define MAX_LARGO_DATE 9

#define DATE_DELIM '-'

#define ID_MENSAJE_POS 0
#define DATE_FIELD_POS 1
#define ID_USUARIO_POS 2

#define MAX_TEXTO 140

typedef struct mensaje {

	time_t fecha;
	int id_mensaje;
	int id_usuario;
	char texto[MAX_TEXTO];

}mensaje_s;

void del_mensaje(mensaje_s * mensaje);
mensaje_s* cargar_mensaje(char * line, status_t * st);
void imprimir_mensaje (mensaje_s * mensaje, FILE * stream);

#endif
