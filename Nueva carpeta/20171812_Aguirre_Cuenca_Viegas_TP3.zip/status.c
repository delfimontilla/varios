#include <stdio.h>

#include "status.h"
#include "idioma.h"

status_t handle_error(status_t status){

	switch(status){
		case ST_ERROR_MEMORIA:
			fprintf(stdout, "%s:%s \n", MSG_ERROR_PREFIX, MSG_ERROR_NO_MEMORY);
			break;

		case ST_ERROR_PUNTERO_NULO:
			fprintf(stdout, "%s:%s \n", MSG_ERROR_PREFIX, MSG_ERROR_NULL_POINTER);
			break;

		case ST_ERROR_ARCHIVO_CORRUPTO:
			fprintf(stdout, "%s:%s \n", MSG_ERROR_PREFIX, MSG_ERROR_OPEN_FILE);
			break;

		case ST_ERROR_ARGUMENTO_INVALIDO:
			fprintf(stdout, "%s:%s \n", MSG_ERROR_PREFIX, MSG_ERROR_INVALID_ARG);
			break;

		case ST_ERROR_DATO_INVALIDO:
			fprintf(stdout, "%s:%s \n", MSG_ERROR_PREFIX, MSG_ERROR_INVALID_DATA);
			break;

		case ST_ERROR_FORMATO:
			fprintf(stdout, "%s:%s \n", MSG_ERROR_PREFIX, MSG_ERROR_FORMATO);
			break;

		default:
			break;
	}

	return ST_OK;
}
