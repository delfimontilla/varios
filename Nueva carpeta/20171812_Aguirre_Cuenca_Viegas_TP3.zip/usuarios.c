#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "listas.h"
#include "status.h"
#include "usuarios.h"
#include "mensajes.h"
#include "utilidades.h"
#include "vector.h"
#include "config.h"


void del_usuario (usuario_s * usuario){

	if (!usuario){
		return;
	}

	free (usuario->nombre);
	usuario->nombre = NULL;
	free(usuario->apodo);
	usuario->apodo = NULL;
	vector_destruir(&(usuario->amigos));
    destruir_lista(&(usuario->mensaje), (void(*)(void*))del_mensaje);
	free(usuario);

}

usuario_s * cargar_usuario(FILE *fin, status_t * st){

	usuario_s *usuario;
	char **csv_fields, *endptr, line[MAX_STR], *aux, *aux_2, campo[MAX_STR], valor[MAX_STR];
	size_t n,i, largo_aux;
	status_t state;
	bool_t bool;
	int aux_int, *p_int;
	mensaje_s * mensaje;
	retval_t rv;

	/*Pido memoria para la estructura*/
	if((usuario = (usuario_s *)malloc(sizeof(usuario_s))) == NULL){
        fclose(fin);
		*st = ST_ERROR_MEMORIA;
		return NULL;
	}

	if((rv = lista_crear (&(usuario->mensaje))) != RV_OK){
		del_usuario(usuario);
		*st = ST_ERROR_PUNTERO_NULO;
		return NULL;
	}
	

	while(fgets(line, MAX_STR, fin) != NULL){

		if(line[0] == '\n'){                     /*si la linea es un '\n', termin� el usuario*/
            *st = ST_OK;
            return usuario;
        }

		if((endptr = strrchr(line, '\n')) != NULL)
			*endptr = '\0';

        /*leo y cargo apodo saltear corchete*/

        if(line[0] == CORCHETE_INICIAL){

            largo_aux = strlen(line) - 2;   /*eliminando los 2 espacios entre el igual*/
            if((usuario->apodo = (char *)malloc(sizeof(char) * (largo_aux + 1))) == NULL){
            	del_usuario(usuario);
                *st = ST_ERROR_MEMORIA;
                return NULL;
            }

            if(line[largo_aux + 1] != CORCHETE_FINAL){
            	del_usuario(usuario);
                *st = ST_ERROR_FORMATO;
                return NULL;
            }

            strncpy(usuario->apodo, line + APODO_POS, largo_aux);
            usuario->apodo[largo_aux] = '\0';
        }

        if((aux = strchr(line, IGUAL_DELIM)) != NULL){

            strncpy(campo, line, aux - line);
        	aux_2 = strchr(campo, ESPACIO);
        	*aux_2 = '\0';

            strcpy(valor, aux +2);

            if(strcmp(campo, MSJ_ID) == 0){
                usuario->id = (int)strtol(valor, &endptr, 10);
                if(*endptr != '\0'){
                	del_usuario(usuario);
                    *st = ST_ERROR_DATO_INVALIDO;
                    return NULL;
                }
            }

            else if(strcmp(campo, MSJ_NOMBRE) == 0){

            	usuario->nombre = strdup (valor);

            }

            else if(strcmp(campo, MSJ_AMIGOS) == 0){

            /*Separo los campos*/
                if((state = split(line + AMIGOS_POS, CHAR_CSV_FIELD_SEPARATOR, &csv_fields, &n)) != ST_OK){
                	del_usuario(usuario);
                    *st = ST_ERROR_DATO_INVALIDO;
                    return NULL;
                }

                usuario->amigos = vector_crear(n);

                for (i = 0; i < n; i++){

                    aux_int = (int)strtol(csv_fields[i], &endptr, 10);
                    if(*endptr != '\0'){
                    	del_usuario(usuario);
                    	del_array(&csv_fields,&n);
                        *st = ST_ERROR_DATO_INVALIDO;
                        return NULL;
                    }

                    p_int = intdup(aux_int);
                    if(!p_int){
                    	del_usuario(usuario);
                        del_array(&csv_fields,&n);
                        *st = ST_ERROR_MEMORIA;
                        return NULL;
                    }

                    if((bool = vector_insertar_al_final(usuario->amigos, (void*)p_int)) == FALSE){
                    	del_usuario(usuario);
                        del_array(&csv_fields,&n);
                        *st = ST_ERROR_DATO_INVALIDO;
                        return NULL;
                    }
                }

                del_array(&csv_fields,&n);
            }

            else if(strcmp(campo,MSJ_MENSAJE) == 0){
            	mensaje = cargar_mensaje(valor, st);
				lista_insertar_final (&(usuario->mensaje), mensaje);

            }
            else{
            	del_usuario(usuario);
                del_array(&csv_fields,&n);
                *st = ST_ERROR_FORMATO;
                return NULL;
            }
        }
	}
	*st = ST_FIN_ARCHIVO;

	return usuario;
}

int cmp_id (const usuario_s * usuario, const usuario_s * buscado){

    return usuario->id - buscado->id;
        
}

int cmp_apodo (const usuario_s * usuario, const usuario_s * buscado){

    if (!strcmp(usuario->apodo, buscado->apodo))
        return 0;

	return 1;
}

void imprimir_usuario(usuario_s * usuario, FILE * stream){

	retval_t rv;
	size_t i, l;
	int * item;

	if((fprintf(stream, "%c",CORCHETE_INICIAL)) < 0)
		return;

	if((fprintf(stream, "%s", usuario->apodo)) < 0)
		return;

	if((fprintf(stream, "%c\n", CORCHETE_FINAL)) < 0)
		return;

	if((fprintf(stream, "%s", MSJ_ID)) < 0)
		return;

	if((fprintf(stream, " %c ", IGUAL_DELIM  )) < 0)
		return;

	if((fprintf(stream, "%d\n", usuario->id)) < 0)
		return;

	if((fprintf(stream, "%s", MSJ_NOMBRE)) < 0)
		return;

    if((fprintf(stream, " %c ", IGUAL_DELIM  )) < 0)
		return;

	if((fprintf(stream, "%s\n", usuario->nombre)) < 0)
		return;

	if((fprintf(stream, "%s", MSJ_AMIGOS)) < 0)
		return;

	if((fprintf(stream, " %c ", IGUAL_DELIM )) < 0)
		return;

	l = vector_largo (usuario->amigos);

	for(i = 0; i < l -1 ; i++){
		item = (int*)vector_obtener(usuario->amigos, i);
		fprintf(stream, "%d", *item);
		fprintf(stream, "%c", CSV_DELIM);
	}

	item = (int*)vector_obtener(usuario->amigos, i);
	fprintf(stream, "%d\n",*item);

	if((rv = lista_recorrer(usuario->mensaje, (void(*)(void*,void*))imprimir_mensaje, stream)) != RV_OK)
		return;

    if((fprintf(stream, "%s", SALTO_DE_LINEA)) == -1)
		return;
}

status_t guardar_usuario(usuario_s * u){

    FILE * fi;

    if(!u || !(u->apodo))
        return ST_ERROR_PUNTERO_NULO;

    if((fi = fopen(u->apodo, "wt")) == NULL){
        return ST_ERROR_ABRIR_ARCHIVO; 
    }

    imprimir_usuario(u,fi);
    fclose(fi);

    return ST_OK;
}
