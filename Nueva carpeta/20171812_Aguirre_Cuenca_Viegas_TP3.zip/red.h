#ifndef RED__H
#define RED__H

#define MIN_ARG_VALUE 6
#define OPERACION_POS 1
#define FILTRO_POS 2
#define POS_OUTPUT_OP 3
#define OUTPUT_POS_MODO 4
#define ARG_POS_ARCHIVO 5

#define INDICADOR_ID 'i'
#define INDICADOR_APODO 'u'
#define INDICADOR_SINGLE "single"
#define INDICADOR_MULTI "multi"
#define DELIM_FILTRO ':'
#define OP_ELIMINAR_1 "-e"
#define OP_ELIMINAR_2 "--eliminar"
#define OP_OUTPUT_1 "-o"
#define OP_OUTPUT_2 "--output"

typedef enum{

	OP_IMPRIMIR_STDOUT,
	OP_IMPRIMIR_MULTI
	
}operation_t;

typedef enum{

	IND_ID,
	IND_APODO
	
}indicador_filtro_t;

status_t validar_argumentos (int argc, char * argv[], usuario_s * buscado, operation_t * op, indicador_filtro_t * indicador);

#endif
