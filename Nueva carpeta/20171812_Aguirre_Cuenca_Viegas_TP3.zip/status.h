#ifndef STATUS__H
#define STATUS__H

typedef enum{

	ST_OK,
	ST_ERROR_ARGUMENTO_INVALIDO,
	ST_ERROR_DATO_INVALIDO,
	ST_ERROR_ARCHIVO_CORRUPTO,
	ST_ERROR_FORMATO,
	ST_ERROR_PUNTERO_NULO,
	ST_ERROR_MEMORIA,
	ST_ERROR_ABRIR_ARCHIVO,
	ST_FIN_ARCHIVO

}status_t;

typedef enum bool {

	TRUE = 1,
	FALSE = 0

} bool_t;

status_t handle_error(status_t status);

#endif
